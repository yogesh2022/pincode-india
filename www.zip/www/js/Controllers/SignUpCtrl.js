angular.module('starter.controllers').controller('SignUpCtrl', function($scope) {
	
});