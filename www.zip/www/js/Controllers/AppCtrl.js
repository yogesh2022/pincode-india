angular.module('starter.controllers', []).controller('AppCtrl', [function($scope) {
  // Form data for the login modal
  
}]);