angular.module('starter.controllers').controller('ForgotPasswordCtrl', function($scope) {
	
});