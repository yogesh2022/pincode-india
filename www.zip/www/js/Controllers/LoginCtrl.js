angular.module('starter.controllers').controller('LoginCtrl', function($scope) {
	
});